export interface Releasable {
    release(): void;
}
