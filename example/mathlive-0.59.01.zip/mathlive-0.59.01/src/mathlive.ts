import MathLiveDebug from './addons/debug';

export const debug = {
    
    latexToAsciiMath: MathLiveDebug.latexToAsciiMath,
    
};
