# MathJS Example

This example shows how to use the output of a MathLive mathfield with the
`mathjs` JavaScript library.
